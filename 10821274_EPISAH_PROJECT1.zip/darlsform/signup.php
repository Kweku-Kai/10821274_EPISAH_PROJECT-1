<?php
session_start();
require_once "connect.php";
#$servername ="localhost";
#$username = "root";
#$password = "";
#$dbname = "darlsworld";
#$conn = new mysqli($servername, $username, $password, $dbname);
#if($conn->connect_error){
	#die("connection failed");
#}
if(isset($_POST["First_name"])) {
$firstname = $_POST["First_name"];
$lastname = $_POST["Last_name"];
$email = $_POST["email"];
$password = $_POST["password"];
//$salt = "codeflix";
//$password_encrypted = sha1($password.$salt);
#if($fname != null && $lname != null && $contact != null && $email != null && $password1 != null && $password2 != null) {

    //Check if passwords are equal
    //if($password1 != $password2) {
    //    echo "Passwords does not match";
   // } else {
        //Check if email is not registered
      //  $password = md5($password1);

        //register user
      //  $register = "INSERT INTO users(id, firstname, lastname, email, tele, password) VALUES('1', '$fname', '$lname', '$email', '$contact', '$password')";
      //  if($sql->query($register)) {
         //   echo "true";

#}
$conn = OpenCon();
$check_email = "SELECT * FROM users WHERE email = '$email'";
$email_result = $conn->query($check_email);
if($email_result->num_rows > 0) {
	$_SESSION["email"] = $email;
	echo "Email is aleady registered";
} else {
	$register = "INSERT INTO users (fname, lname, email, password) 
VALUES ('$firstname', '$lastname', '$email', '$password')";
           $_SESSION["email"] = $email;
		   if($conn->query($register)) {
            echo "true";
            $_SESSION["email"] = $email;

			header("location: ./signlog.html");
			?>
	<script>
		alert('Values have been inserted');
	</script>
	<?php
	//header("location: ./index.php");
}
else{
	?>
	<script>
		alert('user not registered');
	</script>
	<?php
        } //else {
	//echo "user not registered: ".$sql->error;
//}
}

header("location: ./signlog.html");

#if($conn->query($sql) === TRUE){
#
} else {
	echo "You have empty fields";
}

?>




















